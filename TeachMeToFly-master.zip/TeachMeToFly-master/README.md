TeachMeToFly
============

Teach me to fly - 3D game with three.js