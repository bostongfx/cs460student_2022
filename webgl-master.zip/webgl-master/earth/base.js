function textures() {
  var background = null;
  var offscreen = null;
}

function shaders() {
  var base = null;
  var globe = null;
  var blur = null;
}

function buffers() {
  var fullscreen = null;
  var render = null;
  var framebuffer = null;
}

var dimOffscreenTex = 512;
var blurShift = 0.0025;
